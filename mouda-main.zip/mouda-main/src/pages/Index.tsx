
import { motion } from "framer-motion";
import { ArrowRight, Sparkles, BookOpen, Users, Award, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import Navigation from "@/components/Navigation";
import { FeaturesSection } from "@/components/features/FeaturesSection";
import { PricingSection } from "@/components/pricing/PricingSection";
import LogoCarousel from "@/components/LogoCarousel";
import TestimonialsSection from "@/components/TestimonialsSection";
import Footer from "@/components/Footer";
import ContactForm from "@/components/ContactForm";
import CTASection from "@/components/CTASection";

const Index = () => {
  return (
    <div className="min-h-screen bg-black text-white" dir="rtl">
      <Navigation />
      
      {/* Hero Section */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative container px-4 pt-40 pb-20"
      >
        {/* Background */}
        <div className="absolute inset-0 -z-10 bg-[#292929]" />
        
        {/* Gradient blur element */}
        <div 
          className="absolute left-0 top-0 w-full h-full rounded-full"
          style={{
            background: '#fc5c30',
            opacity: 0.1,
            boxShadow: '300px 300px 300px',
            filter: 'blur(150px)',
            zIndex: 1
          }}
        />
        
        <div className="flex flex-col items-center text-center relative z-10">
          {/* Logo Section */}
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            transition={{ delay: 0.2 }} 
            className="mb-8"
          >
            <img 
              src="/lovable-uploads/16363a3b-6926-400a-be9b-cf392f28fe7b.png" 
              alt="مدرس - Moudaris" 
              className="h-20 w-auto mx-auto"
            />
          </motion.div>

          {/* Badge Section */}
          <motion.div initial={{
            opacity: 0
          }} animate={{
            opacity: 1
          }} transition={{
            delay: 0.2
          }} className="inline-block mb-4 px-4 py-1.5 rounded-full glass">
            <span className="text-sm font-medium">
              <Sparkles className="w-4 h-4 inline-block ml-2" />
              منصة التعلم الإلكتروني الرائدة في المغرب
            </span>
          </motion.div>
          
          <div className="max-w-4xl relative z-10">
            {/* Heading and Description */}
            <motion.h1 initial={{
              opacity: 0,
              y: 20
            }} animate={{
              opacity: 1,
              y: 0
            }} transition={{
              delay: 0.3
            }} className="text-5xl md:text-7xl font-normal mb-6 tracking-tight leading-tight">
              <span className="text-white font-medium block mb-2">
                مدرس
              </span>
              <span className="text-gradient font-medium block">
                مركز التميز الأكاديمي
              </span>
            </motion.h1>
            
            <motion.p initial={{
              opacity: 0,
              y: 20
            }} animate={{
              opacity: 1,
              y: 0
            }} transition={{
              delay: 0.4
            }} className="text-lg md:text-xl text-gray-200 mb-8 max-w-2xl mx-auto leading-relaxed">
              نقدم دروس دعم أكاديمي للمستوى الإعدادي والثانوي، بالإضافة إلى دورات في البرمجة والتصميم الجرافيكي.
              <br />
              <span className="text-white font-medium">احجز جلستك الأولى مجاناً واكتشف الفرق معنا.</span>
            </motion.p>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="flex flex-col sm:flex-row gap-4 items-center justify-center"
            >
              <Button 
                size="lg" 
                className="button-gradient"
                onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              >
                ابدأ التعلم الآن
              </Button>
              <Button 
                size="lg" 
                variant="link" 
                className="text-white"
                onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
              >
                تصفح المواد <ArrowRight className="mr-2 w-4 h-4 rotate-180" />
              </Button>
            </motion.div>
          </div>

          {/* Stats Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-20 w-full max-w-4xl"
          >
            <div className="text-center glass rounded-xl p-6">
              <Users className="w-8 h-8 text-orange-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">+500</div>
              <div className="text-sm text-gray-400">طالب متفوق</div>
            </div>
            <div className="text-center glass rounded-xl p-6">
              <BookOpen className="w-8 h-8 text-orange-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">20+</div>
              <div className="text-sm text-gray-400">مادة دراسية</div>
            </div>
            <div className="text-center glass rounded-xl p-6">
              <Award className="w-8 h-8 text-orange-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">15+</div>
              <div className="text-sm text-gray-400">مدرس خبير</div>
            </div>
            <div className="text-center glass rounded-xl p-6">
              <Clock className="w-8 h-8 text-orange-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">7/24</div>
              <div className="text-sm text-gray-400">دعم متواصل</div>
            </div>
          </motion.div>
        </div>
      </motion.section>

      {/* Features Section */}
      <div id="features" className="bg-[#292929]">
        <FeaturesSection />
      </div>

      {/* Pricing Section */}
      <div id="pricing" className="bg-[#292929]">
        <PricingSection />
      </div>

      {/* Testimonials Section */}
      <div className="bg-[#292929]">
        <TestimonialsSection />
      </div>

      {/* Contact Section */}
      <div id="contact" className="bg-[#292929]">
        <ContactForm />
      </div>

      {/* CTA Section */}
      <CTASection />

      {/* Footer */}
      <div className="bg-[#292929]">
        <Footer />
      </div>
    </div>
  );
};

export default Index;
