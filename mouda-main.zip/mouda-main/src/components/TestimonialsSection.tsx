
"use client";

import { motion } from "framer-motion";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Card } from "./ui/card";

const testimonials = [
  {
    name: "أحمد المتوكل",
    role: "طالب ثانوي - الرباط",
    image: "https://avatars.githubusercontent.com/u/1234567?v=4",
    content: "بفضل دروس مدرس، تحسنت درجاتي في الرياضيات من 10/20 إلى 18/20. المدرسون محترفون والمنهجية واضحة جداً."
  },
  {
    name: "فاطمة الزهراء",
    role: "طالبة إعدادي - الدار البيضاء",
    image: "https://avatars.githubusercontent.com/u/2345678?v=4",
    content: "الدروس الإلكترونية مريحة جداً وأستطيع المراجعة في أي وقت. أنصح بمدرس لكل الطلاب الذين يريدون التفوق."
  },
  {
    name: "يوسف بنعلي",
    role: "دارس برمجة - فاس",
    image: "https://avatars.githubusercontent.com/u/3456789?v=4",
    content: "تعلمت البرمجة من الصفر وأصبحت قادراً على إنشاء مواقع إلكترونية. الشرح مبسط والأمثلة عملية."
  },
  {
    name: "مريم العلوي",
    role: "طالبة ثانوي - مراكش",
    image: "https://avatars.githubusercontent.com/u/4567890?v=4",
    content: "دروس الفيزياء والكيمياء أصبحت ممتعة معكم. الجلسة المجانية الأولى كانت كافية لأقرر الاستمرار."
  },
  {
    name: "حمزة الإدريسي",
    role: "دارس تصميم - طنجة",
    image: "https://avatars.githubusercontent.com/u/5678901?v=4",
    content: "دورة التصميم الجرافيكي غيرت مساري المهني. أصبحت أعمل كمصمم مستقل بفضل ما تعلمته معكم."
  },
  {
    name: "خديجة الحسني",
    role: "طالبة إعدادي - أكادير",
    image: "https://avatars.githubusercontent.com/u/6789012?v=4",
    content: "دروس اللغة الفرنسية ساعدتني كثيراً في تحسين مستواي. المدرسة صبورة وتشرح ببساطة."
  }
];

const TestimonialsSection = () => {
  return (
    <section className="py-20 overflow-hidden bg-[#292929]" dir="rtl">
      <div className="container px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl font-normal mb-4 text-white">آراء طلابنا</h2>
          <p className="text-white/70 text-lg">
            انضم إلى آلاف الطلاب الراضين عن خدماتنا التعليمية
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
            >
              <Card className="h-full bg-black/40 backdrop-blur-xl border-white/5 hover:border-orange-500/20 transition-all duration-300 p-6">
                <div className="flex items-center gap-4 mb-4">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={testimonial.image} />
                    <AvatarFallback>{testimonial.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="text-right">
                    <h4 className="font-medium text-white/90">{testimonial.name}</h4>
                    <p className="text-sm text-white/60">{testimonial.role}</p>
                  </div>
                </div>
                <p className="text-white/70 leading-relaxed text-right">
                  {testimonial.content}
                </p>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
