
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Send, X } from "lucide-react";

interface PricingModalProps {
  planName: string;
  children: React.ReactNode;
}

const PricingModal = ({ planName, children }: PricingModalProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    city: "",
    learningType: "",
    academicLevel: "",
    subject: "",
    additionalInfo: ""
  });

  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.phone) {
      toast({
        title: "خطأ",
        description: "يرجى ملء الحقول المطلوبة",
        variant: "destructive",
      });
      return;
    }

    // Prepare WhatsApp message
    let message = `🎓 طلب اشتراك في ${planName}\n\n`;
    message += `👤 الاسم: ${formData.name}\n`;
    message += `📧 البريد الإلكتروني: ${formData.email}\n`;
    message += `📱 رقم الهاتف: ${formData.phone}\n`;
    
    if (formData.city) message += `🏙️ المدينة: ${formData.city}\n`;
    if (formData.learningType) message += `📚 نوع التعلم: ${formData.learningType}\n`;
    if (formData.academicLevel) message += `🎯 المستوى: ${formData.academicLevel}\n`;
    if (formData.subject) message += `📖 المادة: ${formData.subject}\n`;
    if (formData.additionalInfo) message += `📝 معلومات إضافية: ${formData.additionalInfo}\n`;
    
    message += `\n✨ سيتواصل معك فريقنا في أقرب وقت ممكن لتأكيد التفاصيل وبدء رحلتك التعليمية!`;

    // Send to WhatsApp
    const whatsappNumber = "+212652741006";
    const whatsappUrl = `https://wa.me/${whatsappNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(message)}`;
    
    window.open(whatsappUrl, '_blank');
    
    toast({
      title: "تم إرسال الطلب!",
      description: "سيتواصل معك فريقنا قريباً",
    });

    setIsOpen(false);
    setFormData({
      name: "",
      email: "",
      phone: "",
      city: "",
      learningType: "",
      academicLevel: "",
      subject: "",
      additionalInfo: ""
    });
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="max-w-md mx-auto max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-right text-xl">اشتراك في {planName}</DialogTitle>
          <DialogDescription className="text-right text-gray-600">
            املأ البيانات التالية وسنتواصل معك قريباً
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-right block">الاسم الكامل *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleInputChange("name", e.target.value)}
              placeholder="أدخل اسمك الكامل"
              className="text-right"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="email" className="text-right block">البريد الإلكتروني *</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange("email", e.target.value)}
              placeholder="أدخل بريدك الإلكتروني"
              className="text-right"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone" className="text-right block">رقم الهاتف *</Label>
            <Input
              id="phone"
              type="tel"
              value={formData.phone}
              onChange={(e) => handleInputChange("phone", e.target.value)}
              placeholder="أدخل رقم هاتفك"
              className="text-right"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="city" className="text-right block">المدينة</Label>
            <Input
              id="city"
              value={formData.city}
              onChange={(e) => handleInputChange("city", e.target.value)}
              placeholder="أدخل مدينتك"
              className="text-right"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-right block">نوع التعلم المطلوب</Label>
            <Select onValueChange={(value) => handleInputChange("learningType", value)}>
              <SelectTrigger className="text-right">
                <SelectValue placeholder="اختر نوع التعلم" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="دعم أكاديمي">دعم أكاديمي</SelectItem>
                <SelectItem value="تعلم اللغات">تعلم اللغات</SelectItem>
                <SelectItem value="برمجة وتصميم">برمجة وتصميم</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {formData.learningType === "دعم أكاديمي" && (
            <>
              <div className="space-y-2">
                <Label className="text-right block">المستوى الدراسي</Label>
                <Select onValueChange={(value) => handleInputChange("academicLevel", value)}>
                  <SelectTrigger className="text-right">
                    <SelectValue placeholder="اختر المستوى" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="إعدادي">المستوى الإعدادي</SelectItem>
                    <SelectItem value="ثانوي">المستوى الثانوي</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label className="text-right block">المادة</Label>
                <Select onValueChange={(value) => handleInputChange("subject", value)}>
                  <SelectTrigger className="text-right">
                    <SelectValue placeholder="اختر المادة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="رياضيات">الرياضيات</SelectItem>
                    <SelectItem value="فيزياء">الفيزياء</SelectItem>
                    <SelectItem value="كيمياء">الكيمياء</SelectItem>
                    <SelectItem value="علوم الحياة والأرض">علوم الحياة والأرض</SelectItem>
                    <SelectItem value="عربية">اللغة العربية</SelectItem>
                    <SelectItem value="فرنسية">اللغة الفرنسية</SelectItem>
                    <SelectItem value="إنجليزية">اللغة الإنجليزية</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </>
          )}

          <div className="space-y-2">
            <Label htmlFor="additionalInfo" className="text-right block">معلومات إضافية</Label>
            <Textarea
              id="additionalInfo"
              value={formData.additionalInfo}
              onChange={(e) => handleInputChange("additionalInfo", e.target.value)}
              placeholder="أخبرنا المزيد عن احتياجاتك..."
              className="min-h-[80px] text-right"
            />
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="submit" className="flex-1 button-gradient">
              <Send className="ml-2 w-4 h-4" />
              إرسال الطلب
            </Button>
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setIsOpen(false)}
              className="px-4"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default PricingModal;
