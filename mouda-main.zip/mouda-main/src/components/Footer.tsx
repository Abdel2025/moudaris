
import { Phone, Mail, MapPin } from "lucide-react";
import { Button } from "./ui/button";

const Footer = () => {
  return (
    <footer className="w-full py-12 mt-20 bg-gray-900" dir="rtl">
      <div className="container px-4">
        <div className="bg-gray-800/50 backdrop-blur-xl border border-gray-700/50 rounded-xl p-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <img 
                  src="/lovable-uploads/16363a3b-6926-400a-be9b-cf392f28fe7b.png" 
                  alt="مدرس" 
                  className="h-8 w-auto"
                />
              </div>
              <p className="text-sm text-gray-300 text-right">
                مركز التميز الأكاديمي الرائد في المغرب لتقديم أفضل خدمات التعلم الإلكتروني.
              </p>
              <div className="flex space-x-4">
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => window.open("https://wa.me/212652741006", "_blank")}
                >
                  <Phone className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Mail className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium text-right text-white">خدماتنا</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#features" className="text-sm text-gray-300 hover:text-orange-500 transition-colors">
                    دعم أكاديمي
                  </a>
                </li>
                <li>
                  <a href="#features" className="text-sm text-gray-300 hover:text-orange-500 transition-colors">
                    تعلم اللغات
                  </a>
                </li>
                <li>
                  <a href="#features" className="text-sm text-gray-300 hover:text-orange-500 transition-colors">
                    برمجة وتصميم
                  </a>
                </li>
              </ul>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium text-right text-white">المستويات</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#pricing" className="text-sm text-gray-300 hover:text-orange-500 transition-colors">
                    المستوى الإعدادي
                  </a>
                </li>
                <li>
                  <a href="#pricing" className="text-sm text-gray-300 hover:text-orange-500 transition-colors">
                    المستوى الثانوي
                  </a>
                </li>
              </ul>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium text-right text-white">تواصل معنا</h4>
              <ul className="space-y-2">
                <li className="flex items-center gap-2 text-sm text-gray-300">
                  <Phone className="w-4 h-4 text-orange-500" />
                  <span>+212 652‑741006</span>
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-300">
                  <MapPin className="w-4 h-4 text-orange-500" />
                  <span>المغرب</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-gray-700">
            <p className="text-sm text-gray-400 text-center">
              © {new Date().getFullYear()} مدرس. جميع الحقوق محفوظة.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
