
import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CardSpotlight } from "./CardSpotlight";
import PricingModal from "../PricingModal";

const PricingTier = ({
  name,
  price,
  description,
  features,
  isPopular,
}: {
  name: string;
  price: string;
  description: string;
  features: string[];
  isPopular?: boolean;
}) => (
  <CardSpotlight className={`h-full ${isPopular ? "border-orange-500" : "border-white/10"} border-2`}>
    <div className="relative h-full p-6 flex flex-col">
      {isPopular && (
        <span className="text-xs font-medium bg-orange-500/10 text-orange-500 rounded-full px-3 py-1 w-fit mb-4">
          الأكثر شعبية
        </span>
      )}
      <h3 className="text-xl font-medium mb-2 text-right text-white">{name}</h3>
      <div className="mb-4 text-right">
        <span className="text-4xl font-bold text-white">{price}</span>
        {price !== "حسب الطلب" && <span className="text-gray-400">/شهر</span>}
      </div>
      <p className="text-gray-400 mb-6 text-right">{description}</p>
      <ul className="space-y-3 mb-8 flex-grow">
        {features.map((feature, index) => (
          <li key={index} className="flex items-center gap-2 text-right">
            <Check className="w-5 h-5 text-orange-500 flex-shrink-0" />
            <span className="text-sm text-gray-300">{feature}</span>
          </li>
        ))}
      </ul>
      <PricingModal planName={name}>
        <Button className="button-gradient w-full">
          ابدأ الآن
        </Button>
      </PricingModal>
    </div>
  </CardSpotlight>
);

export const PricingSection = () => {
  return (
    <section className="container px-4 py-24" dir="rtl">
      <div className="max-w-2xl mx-auto text-center mb-12">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-5xl md:text-6xl font-normal mb-6 text-white"
        >
          اختر خطتك{" "}
          <span className="text-gradient font-medium">التعليمية</span>
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.5 }}
          className="text-lg text-gray-400"
        >
          اختر الخطة المناسبة لك وابدأ رحلتك التعليمية مع أفضل المدرسين
        </motion.p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        <PricingTier
          name="الباقة الأساسية"
          price="200 درهم"
          description="مثالية للطلاب المبتدئين"
          features={[
            "4 جلسات شهرياً",
            "دعم في مادة واحدة",
            "جلسة مجانية تجريبية",
            "دعم عبر WhatsApp"
          ]}
        />
        <PricingTier
          name="الباقة المتقدمة"
          price="350 درهم"
          description="الأكثر شعبية للطلاب الجادين"
          features={[
            "8 جلسات شهرياً",
            "دعم في 3 مواد",
            "متابعة أسبوعية",
            "واجبات وتمارين إضافية",
            "دعم 24/7",
            "تقارير تقدم شهرية"
          ]}
          isPopular
        />
        <PricingTier
          name="الباقة المميزة"
          price="حسب الطلب"
          description="للطلاب الذين يريدون التميز"
          features={[
            "جلسات غير محدودة",
            "دعم في جميع المواد",
            "مدرس مخصص",
            "برنامج مخصص",
            "دعم الامتحانات",
            "استشارات أكاديمية"
          ]}
        />
      </div>
    </section>
  );
};
