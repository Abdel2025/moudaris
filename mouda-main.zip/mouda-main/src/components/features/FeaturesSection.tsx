
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FeatureTab } from "./FeatureTab";
import { FeatureContent } from "./FeatureContent";
import { BookOpen, Users, Award, Clock, Laptop, Languages } from "lucide-react";

const features = [
  {
    title: "دعم أكاديمي شامل",
    description: "دروس مخصصة للمستوى الإعدادي والثانوي في جميع المواد الأساسية",
    icon: <BookOpen className="w-6 h-6" />,
    image: "/lovable-uploads/94bdaf81-fe3d-4951-b440-b78d1c041138.png"
  },
  {
    title: "فريق من الخبراء",
    description: "مدرسون مؤهلون وذوو خبرة واسعة في التدريس الإلكتروني",
    icon: <Users className="w-6 h-6" />,
    image: "/lovable-uploads/94bdaf81-fe3d-4951-b440-b78d1c041138.png"
  },
  {
    title: "منهجية واضحة",
    description: "نتبع منهجية تعليمية مدروسة تضمن تحقيق أفضل النتائج",
    icon: <Award className="w-6 h-6" />,
    image: "/lovable-uploads/94bdaf81-fe3d-4951-b440-b78d1c041138.png"
  },
  {
    title: "برمجة وتصميم",
    description: "دورات متخصصة في البرمجة والتصميم الجرافيكي للمبتدئين والمتقدمين",
    icon: <Laptop className="w-6 h-6" />,
    image: "/lovable-uploads/94bdaf81-fe3d-4951-b440-b78d1c041138.png"
  },
  {
    title: "تعلم اللغات",
    description: "دروس في الفرنسية والإنجليزية مع التركيز على المحادثة والقواعد",
    icon: <Languages className="w-6 h-6" />,
    image: "/lovable-uploads/94bdaf81-fe3d-4951-b440-b78d1c041138.png"
  },
  {
    title: "جلسة مجانية",
    description: "جرب خدماتنا مجاناً في الجلسة الأولى قبل أن تلتزم بالدورة",
    icon: <Clock className="w-6 h-6" />,
    image: "/lovable-uploads/94bdaf81-fe3d-4951-b440-b78d1c041138.png"
  }
];

export const FeaturesSection = () => {
  return (
    <section className="container px-4 py-24 relative" dir="rtl">
      
      {/* Gradient blur element */}
      <div 
        className="absolute bottom-0 left-0 w-full h-full rounded-full"
        style={{
          background: '#fc5c30',
          opacity: 0.1,
          boxShadow: '300px 300px 300px',
          filter: 'blur(150px)',
          zIndex: 1
        }}
      />
      
      {/* Header Section */}
      <div className="max-w-2xl mb-20 relative z-10 text-right">
        <h2 className="text-5xl md:text-6xl font-normal mb-6 tracking-tight">
          منصة التعلم الإلكتروني
          <br />
          <span className="text-gradient font-medium">الأكثر تطوراً</span>
        </h2>
        <p className="text-lg md:text-xl text-gray-400">
          نقدم تجربة تعليمية متميزة بأحدث الأساليب والتقنيات لضمان وصولك إلى أهدافك الأكاديمية والمهنية.
        </p>
      </div>

      <Tabs defaultValue={features[0].title} className="w-full relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12">
          {/* Left side - Tab content with images */}
          <div className="md:col-span-7 order-1">
            {features.map((feature) => (
              <TabsContent
                key={feature.title}
                value={feature.title}
                className="mt-0 h-full"
              >
                <FeatureContent
                  image={feature.image}
                  title={feature.title}
                />
              </TabsContent>
            ))}
          </div>

          {/* Right side - Tab triggers */}
          <div className="md:col-span-5 space-y-3 order-2">
            <TabsList className="flex flex-col w-full bg-transparent h-auto p-0 space-y-3">
              {features.map((feature) => (
                <TabsTrigger
                  key={feature.title}
                  value={feature.title}
                  className="w-full data-[state=active]:shadow-none data-[state=active]:bg-transparent"
                >
                  <FeatureTab
                    title={feature.title}
                    description={feature.description}
                    icon={feature.icon}
                    isActive={false}
                  />
                </TabsTrigger>
              ))}
            </TabsList>
          </div>
        </div>
      </Tabs>
    </section>
  );
};
