
import { motion } from "framer-motion";
import { ReactNode } from "react";

interface FeatureTabProps {
  icon: ReactNode;
  title: string;
  description: string;
  isActive: boolean;
}

export const FeatureTab = ({ icon, title, description, isActive }: FeatureTabProps) => {
  return (
    <div 
      className={`
        w-full flex items-center gap-4 p-5 rounded-xl
        transition-all duration-300 relative
        ${isActive 
          ? 'glass shadow-lg shadow-primary/10' 
          : 'hover:glass-hover'
        }
      `}
      dir="rtl"
    >
      {isActive && (
        <motion.div
          layoutId="activeTab"
          className="absolute right-0 top-0 w-1 h-full bg-primary rounded-r-xl"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.2 }}
        />
      )}
      <div className="flex items-center gap-4 min-w-0 w-full">
        <div className="text-right min-w-0 flex-1">
          <h3 className={`font-semibold truncate text-base text-white ${isActive ? 'text-primary' : ''}`}>
            {title}
          </h3>
          <p className="text-sm text-gray-300 line-clamp-2">
            {description}
          </p>
        </div>
        <div className={`${isActive ? 'text-primary' : 'text-gray-300'}`}>
          {icon}
        </div>
      </div>
    </div>
  );
};
