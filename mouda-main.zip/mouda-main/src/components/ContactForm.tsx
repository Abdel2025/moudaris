
import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Send, Phone } from "lucide-react";

const ContactForm = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    city: "",
    learningType: "",
    academicLevel: "",
    subject: "",
    language: "",
    specialization: "",
    additionalInfo: ""
  });

  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.learningType) {
      toast({
        title: "خطأ",
        description: "يرجى ملء الحقول المطلوبة",
        variant: "destructive",
      });
      return;
    }

    // Prepare WhatsApp message
    let message = `🎓 طلب جديد من موقع مدرس\n\n`;
    message += `👤 الاسم: ${formData.name}\n`;
    message += `📧 البريد الإلكتروني: ${formData.email}\n`;
    
    if (formData.city) message += `🏙️ المدينة: ${formData.city}\n`;
    
    message += `📚 نوع التعلم: ${formData.learningType}\n`;
    
    if (formData.learningType === "دعم أكاديمي") {
      message += `🎯 المستوى: ${formData.academicLevel}\n`;
      message += `📖 المادة: ${formData.subject}\n`;
    } else if (formData.learningType === "تعلم اللغات") {
      message += `🌍 اللغة: ${formData.language}\n`;
    } else if (formData.learningType === "برمجة وتصميم") {
      message += `💻 التخصص: ${formData.specialization}\n`;
    }
    
    if (formData.additionalInfo) {
      message += `📝 معلومات إضافية: ${formData.additionalInfo}\n`;
    }

    // Send to WhatsApp
    const whatsappNumber = "+212652741006";
    const whatsappUrl = `https://wa.me/${whatsappNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(message)}`;
    
    window.open(whatsappUrl, '_blank');
    
    toast({
      title: "تم إرسال الطلب!",
      description: "سيتم توجيهك إلى WhatsApp لإكمال المحادثة",
    });
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <section className="container px-4 py-24 relative" dir="rtl">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-white">
            ابدأ رحلتك التعليمية معنا
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            احجز جلستك الأولى مجاناً واكتشف كيف يمكننا مساعدتك في تحقيق أهدافك الأكاديمية
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="glass rounded-2xl overflow-hidden"
        >
          <div className="p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-right block text-white">الاسم الكامل *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => handleInputChange("name", e.target.value)}
                    placeholder="أدخل اسمك الكامل"
                    className="text-right"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-right block text-white">البريد الإلكتروني *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    placeholder="أدخل بريدك الإلكتروني"
                    className="text-right"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="city" className="text-right block text-white">المدينة (اختياري)</Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => handleInputChange("city", e.target.value)}
                  placeholder="أدخل مدينتك"
                  className="text-right"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-right block text-white">نوع التعلم المطلوب *</Label>
                <Select onValueChange={(value) => handleInputChange("learningType", value)}>
                  <SelectTrigger className="text-right">
                    <SelectValue placeholder="اختر نوع التعلم" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="دعم أكاديمي">دعم أكاديمي</SelectItem>
                    <SelectItem value="تعلم اللغات">تعلم اللغات</SelectItem>
                    <SelectItem value="برمجة وتصميم">برمجة وتصميم</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {formData.learningType === "دعم أكاديمي" && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label className="text-right block text-white">المستوى الدراسي</Label>
                    <Select onValueChange={(value) => handleInputChange("academicLevel", value)}>
                      <SelectTrigger className="text-right">
                        <SelectValue placeholder="اختر المستوى" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="إعدادي">المستوى الإعدادي</SelectItem>
                        <SelectItem value="ثانوي">المستوى الثانوي</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-right block text-white">المادة</Label>
                    <Select onValueChange={(value) => handleInputChange("subject", value)}>
                      <SelectTrigger className="text-right">
                        <SelectValue placeholder="اختر المادة" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="رياضيات">الرياضيات</SelectItem>
                        <SelectItem value="فيزياء">الفيزياء</SelectItem>
                        <SelectItem value="كيمياء">الكيمياء</SelectItem>
                        <SelectItem value="علوم الحياة والأرض">علوم الحياة والأرض</SelectItem>
                        <SelectItem value="عربية">اللغة العربية</SelectItem>
                        <SelectItem value="فرنسية">اللغة الفرنسية</SelectItem>
                        <SelectItem value="إنجليزية">اللغة الإنجليزية</SelectItem>
                        <SelectItem value="تاريخ وجغرافيا">التاريخ والجغرافيا</SelectItem>
                        <SelectItem value="تربية إسلامية">التربية الإسلامية</SelectItem>
                        <SelectItem value="فلسفة">الفلسفة</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}

              {formData.learningType === "تعلم اللغات" && (
                <div className="space-y-2">
                  <Label className="text-right block text-white">اللغة المطلوبة</Label>
                  <Select onValueChange={(value) => handleInputChange("language", value)}>
                    <SelectTrigger className="text-right">
                      <SelectValue placeholder="اختر اللغة" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="فرنسية">الفرنسية</SelectItem>
                      <SelectItem value="إنجليزية">الإنجليزية</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              {formData.learningType === "برمجة وتصميم" && (
                <div className="space-y-2">
                  <Label className="text-right block text-white">التخصص</Label>
                  <Select onValueChange={(value) => handleInputChange("specialization", value)}>
                    <SelectTrigger className="text-right">
                      <SelectValue placeholder="اختر التخصص" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="برمجة">البرمجة</SelectItem>
                      <SelectItem value="تصميم جرافيكي">التصميم الجرافيكي</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="additionalInfo" className="text-right block text-white">معلومات إضافية (اختياري)</Label>
                <Textarea
                  id="additionalInfo"
                  value={formData.additionalInfo}
                  onChange={(e) => handleInputChange("additionalInfo", e.target.value)}
                  placeholder="أخبرنا المزيد عن احتياجاتك..."
                  className="min-h-[100px] text-right"
                />
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button type="submit" size="lg" className="button-gradient">
                  <Send className="ml-2 w-4 h-4" />
                  إرسال الطلب
                </Button>
                <Button 
                  type="button" 
                  size="lg" 
                  variant="outline"
                  onClick={() => window.open("https://wa.me/212652741006", "_blank")}
                  className="border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white"
                >
                  <Phone className="ml-2 w-4 h-4" />
                  تواصل مباشر
                </Button>
              </div>
            </form>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default ContactForm;
